module.exports = {
  content: [
    "./index.html", // Include your HTML files
    "./src/**/*.{vue,js}", // Include Vue.js files
    // Add other file paths as needed
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
