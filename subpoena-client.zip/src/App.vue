<template>
  <!-- The root template of the Vue component -->
  <div id="app">
    <!-- The router-view component, which renders the current route's component -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App', // The name of the Vue component
};
</script>

<style>
/* Global styles can be added here if neede */
</style>
