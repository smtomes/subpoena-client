<template>
  <div class="bg-gray-100 min-h-screen p-4">
    <div class="max-w-3xl mx-auto bg-white p-8 rounded-lg shadow-lg">
      <h1 class="text-3xl font-semibold mb-6">Welcome to the BlackBox Client</h1>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label class="block text-lg font-semibold mb-2" for="causeNumber">Cause Number:</label>
          <input
            id="causeNumber"
            v-model="causeNumber"
            placeholder="Enter Cause Number"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="courtNumber">Court:</label>
          <select
            id="courtNumber"
            v-model="courtNumber"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          >
            <option value="52nd">52nd</option>
            <option value="440th">440th</option>
          </select>
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="defendantName">Defendant's Name:</label>
          <input
            id="defendantName"
            v-model="defendantName"
            placeholder="Enter Defendant's Name"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="proceeding">Proceeding:</label>
          <input
            id="proceeding"
            v-model="proceeding"
            placeholder="Enter Proceeding"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="appearanceDate">Appearance Date:</label>
          <input
            id="appearanceDate"
            v-model="appearanceDate"
            placeholder="Enter Appearance Date"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="appearanceLocation">Appearance Location:</label>
          <select
            id="appearanceLocation"
            v-model="appearanceLocation"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          >
            <option value="52nd Courthouse">52nd Courthouse</option>
            <option value="440th Courthouse">440th Courthouse</option>
            <option value="Gatesville Civic Center">Gatesville Civic Center</option>
          </select>
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="witnessName">Witness Name:</label>
          <input
            id="witnessName"
            v-model="witnessName"
            placeholder="Enter Witness Name"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="witnessAddress">Witness Address:</label>
          <input
            id="witnessAddress"
            v-model="witnessAddress"
            placeholder="Enter Witness Address"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="witnessPhoneNumber">Witness Phone Number:</label>
          <input
            id="witnessPhoneNumber"
            v-model="witnessPhoneNumber"
            placeholder="Enter Witness Phone Number"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="witnessVocation">Witness Vocation:</label>
          <input
            id="witnessVocation"
            v-model="witnessVocation"
            placeholder="Enter Witness Vocation"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="serviceDate">Service Date:</label>
          <input
            id="serviceDate"
            v-model="serviceDate"
            placeholder="Enter Service Date"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="prosecutor">Prosecutor:</label>
          <select
            id="prosecutor"
            v-model="selectedProsecutor"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          >
            <option v-for="prosecutor in prosecutors" :value="prosecutor">
              {{ prosecutor.name }}
            </option>
          </select>
        </div>
        <div>
          <label class="block text-lg font-semibold mb-2" for="ducesTecumApplication">Duces Tecum:</label>
          <input
            id="ducesTecumApplication"
            v-model="ducesTecumApplication"
            placeholder="Enter Duces Tecum Application"
            class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:border-blue-400"
          />
        </div>
      </div>
      <!-- Add a flashy style to this div -->
      <div class="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 text-white text-center py-4 rounded-lg">
        Flashy Content
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      causeNumber: "",
      courtNumber: "",
      defendantName: "",
      proceeding: "Jury Trial",
      appearanceDate: "",
      appearanceLocation: "",
      witnessName: "",
      witnessAddress: "",
      witnessPhoneNumber: "",
      witnessVocation: "Unknown",
      serviceDate: "",
      prosecutor: "",
      stateBarNo: "",
      email: "",
      title: "",
      ducesTecumApplication: "",
      selectedProsecutor: null,
      prosecutors: [
        // Define prosecutor data here
      ]
    };
  },
  // ... (other Vue.js options and methods)
};
</script>

<style>
/* You can add global styles here if needed */
</style>
